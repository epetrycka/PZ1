package CSVReader;

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.*;
import java.util.function.Predicate;

public class AdminUnitList {
    public List<AdminUnit> units = new ArrayList<>();

    public void read(String filename) throws IOException {
        CSVReader reader = new CSVReader(new FileReader(filename), ",", true);
        Map<Long, AdminUnit> ids = new HashMap<>();
        Map<AdminUnit, Long> parents = new HashMap<>();
        Map<Long,List<AdminUnit>> parentid2child = new HashMap<>();

        while (reader.next()){
            String name = reader.get("name");
            Integer admin_level = reader.getInt("admin_level");
            Double population = reader.getDouble("population");
            Double area = reader.getDouble("area");
            Double density = reader.getDouble("density");
            AdminUnit currentUnit = new AdminUnit(name, admin_level, population, area, density);
            units.add(currentUnit);
            Long parentId = reader.getLong("parent");
            ids.put(reader.getLong("id"), currentUnit);
            parents.put(currentUnit, parentId);
            if (parentId != null) {
                parentid2child.putIfAbsent(parentId, new ArrayList<>());
                parentid2child.get(parentId).add(currentUnit);
            }
            currentUnit.bbox = new BoundingBox();
            currentUnit.bbox.addPoint(reader.getDouble("x1"), reader.getDouble("y1"));
            currentUnit.bbox.addPoint(reader.getDouble("x2"), reader.getDouble("y2"));
            currentUnit.bbox.addPoint(reader.getDouble("x3"), reader.getDouble("y3"));
            currentUnit.bbox.addPoint(reader.getDouble("x4"), reader.getDouble("y4"));
            currentUnit.bbox.addPoint(reader.getDouble("x5"), reader.getDouble("y5"));
        }

        for (AdminUnit unit : units) {
            Long parentId = parents.get(unit);
            if (parentId == null) {
                unit.parent = null;
            } else {
                unit.parent = ids.get(parentId);

            }
            unit.fixMissingValues();

            List<AdminUnit> children = parentid2child.get(parentId);
            if (unit.children != null) {
                unit.children.addAll(children);
            }
        }
    }

    void list(PrintStream out){
        for (AdminUnit unit : units){
            AdminUnit.show(unit, out);
        }
    }

    void list(PrintStream out,int offset, int limit){
        for (int i=offset; i<limit; i++){
            AdminUnit.show(units.get(i), out);
        }
    }

    AdminUnitList selectByName(String pattern, boolean regex){
        AdminUnitList ret = new AdminUnitList();
        for (AdminUnit unit : units) {
            String name = unit.name;
            if (regex) {
                if (name.matches(pattern)) {
                    ret.units.add(unit);
                }
            }
            else {
                if (name.contains(pattern)) {
                    ret.units.add(unit);
                }
            }
        }
        return ret;
    }

    AdminUnitList selectByParent(String pattern, boolean regex){
        AdminUnitList ret = new AdminUnitList();
        for (AdminUnit unit : units) {
            if (unit.parent != null) {
                String parentName = unit.parent.name;
                if (regex) {
                    if (parentName.matches(pattern)) {
                        ret.units.add(unit);
                    }
                } else {
                    if (parentName.contains(pattern)) {
                        ret.units.add(unit);
                    }
                }
            }
        }
        return ret;
    }

    public AdminUnitList getNeighbors(AdminUnit unit, double maxdistance) {
        AdminUnitList neighbors = new AdminUnitList();

        for (AdminUnit candidate : units) {
            if (candidate.adminLevel != unit.adminLevel) continue;
            if (candidate.name == unit.name) continue;

            if (unit.adminLevel <= 8) {
                if (unit.bbox.intersects(candidate.bbox)) {
                    neighbors.units.add(candidate);
                }
            } else {
                if (unit.bbox.distanceTo(candidate.bbox) <= maxdistance) {
                    neighbors.units.add(candidate);
                }
            }
        }

        return neighbors;
    }

    public AdminUnit findByName(String name) throws IOException {
        for (AdminUnit unit : units) {
            if (unit.name.equals(name)) return unit;
        }
        throw new IOException ("No such admin unit");
    }

    public String getWKT(){
        StringBuilder sb = new StringBuilder();
        for (AdminUnit unit : units) {
            sb.append(unit.bbox.getWKT());
        }
        return sb.toString();
    }

    public AdminUnit findByNameAndLevel(String name, int admin_level){
        for (AdminUnit unit : units) {
            if (unit.name.equals(name) && unit.adminLevel == admin_level) {
                return unit;
            }
        }
        return null;
    }

    public AdminUnitList sortInplaceByName(){

        class Compare implements Comparator<AdminUnit> {
            public int compare(AdminUnit t, AdminUnit t1){
                return t.name.compareTo(t1.name);
            }
        }

        units.sort(new Compare());
        return this;
    }

    AdminUnitList sortInplaceByArea(){
        units.sort(new Comparator <AdminUnit> ()
        { public int compare(AdminUnit t, AdminUnit t1) { return Double.compare
                (t1.area == null ? Double.NaN: t1.area,
                        t.area == null ? Double.NaN: t.area); }});
        return this;
    }

    AdminUnitList sortInplaceByPopulation(){
        units.sort((t, t1) -> Double.compare
                (t.population == null? Double.NaN : t.population,
                        t1.population == null ? Double.NaN: t1.population));
        return this;
    }

    AdminUnitList sortInplace(Comparator<AdminUnit> cmp){
        units.sort(cmp);
        return this;
    }

    AdminUnitList sort(Comparator<AdminUnit> cmp){
        AdminUnitList copy = new AdminUnitList();
        copy.units = new ArrayList<>(this.units);
        copy.sortInplace(cmp);
        return copy;
    }

    AdminUnitList filter(Predicate<AdminUnit> pred){
        AdminUnitList copy = new AdminUnitList();
        for (AdminUnit unit : units) {
            if (unit != null && pred != null && pred.test(unit)) {
                copy.units.add(unit);
            }
        }
        return copy;
    }

    AdminUnitList filter(Predicate<AdminUnit> pred, int limit){
        AdminUnitList copy = new AdminUnitList();
        int count = 0;
        for (AdminUnit unit : units) {
            if (unit != null && pred != null && pred.test(unit)) {
                copy.units.add(unit);
                count++;
            }
            if (count >= limit) {
                break;
            }
        }
        return copy;
    }

    AdminUnitList filter(Predicate<AdminUnit> pred, int offset, int limit){
        AdminUnitList copy = new AdminUnitList();
        int count = 0;
        for (AdminUnit unit : units) {
            if (unit != null && pred != null && pred.test(unit)) {
                count++;
                if (count >= offset && count < limit) {
                    copy.units.add(unit);
                }
            }
            if (count >= limit) {
                break;
            }
        }
        return copy;
    }
}