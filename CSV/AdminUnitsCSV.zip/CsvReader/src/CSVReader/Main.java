package CSVReader;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        CSVReader adminunits = new CSVReader("admin-units.csv", ",", true);
        System.out.println(adminunits.getColumnLabels());
        AdminUnitList adminUnitList = new AdminUnitList();
        adminUnitList.read("admin-units.csv");
        AdminUnitList list = adminUnitList.selectByName("^wojew.*", true);
        double t1 = System.nanoTime() / 1e6;
        AdminUnitList neighbours = adminUnitList.getNeighbors(adminUnitList.findByNameAndLevel("Horodło", 8), 15);
        double t2 = System.nanoTime() / 1e6;
        //list.list(System.out);
        neighbours.list(System.out);
        System.out.println(neighbours.getWKT());
        System.out.println("Czas wyszukiwania: " + (t2-t1));
        adminUnitList.filter(a->a.name.startsWith("Ż")).sortInplaceByArea().list(System.out);
        AdminUnitQuery query = new AdminUnitQuery()
                .selectFrom(adminUnitList)
                .where(a->a.area != null && a.area>1000)
                .or(a->a.name.startsWith("Sz"))
                .sort((a,b)->Double.compare(a.area,b.area))
                .limit(100);
        query.execute().list(System.out);
        System.out.println("Working directory: " + System.getProperty("user.dir"));
    }
}